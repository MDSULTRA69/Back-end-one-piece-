export interface LevelInfo {
  level: number;
  rank: string;
  xpForNextLevel: number | null;
  xpProgress: number;
}

const RANKS: Array<{ minXp: number; rank: string }> = [
  { minXp: 0, rank: "East Blue Rookie" },
  { minXp: 100, rank: "Grand Line Pirate" },
  { minXp: 300, rank: "New World Challenger" },
  { minXp: 600, rank: "Warlord of the Sea" },
  { minXp: 1000, rank: "Revolutionary" },
  { minXp: 1500, rank: "Yonko Commander" },
  { minXp: 2200, rank: "Yonko" },
  { minXp: 3100, rank: "Admiral" },
  { minXp: 4200, rank: "Fleet Admiral" },
  { minXp: 5500, rank: "Pirate King" },
];

export function getLevelInfo(xp: number): LevelInfo {
  let level = 1;
  let rank = RANKS[0].rank;
  let xpForNextLevel: number | null = RANKS[1].minXp;

  for (let i = RANKS.length - 1; i >= 0; i--) {
    if (xp >= RANKS[i].minXp) {
      level = i + 1;
      rank = RANKS[i].rank;
      xpForNextLevel = i < RANKS.length - 1 ? RANKS[i + 1].minXp : null;
      break;
    }
  }

  const prevThreshold = RANKS[level - 1].minXp;
  const nextThreshold = xpForNextLevel ?? xp;
  const xpProgress =
    xpForNextLevel !== null
      ? Math.round(((xp - prevThreshold) / (nextThreshold - prevThreshold)) * 100)
      : 100;

  return { level, rank, xpForNextLevel, xpProgress };
}

export function calcXpForResult(won: boolean, guessCount: number): number {
  if (!won) return 10;
  const bonusMap: Record<number, number> = {
    1: 50,
    2: 40,
    3: 30,
    4: 20,
    5: 10,
    6: 0,
  };
  return 100 + (bonusMap[guessCount] ?? 0);
}
