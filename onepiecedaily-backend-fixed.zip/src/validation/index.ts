import * as zod from "zod";

export const RegisterBody = zod.object({
  username: zod.string().min(3).max(20),
  email: zod.string().email(),
  password: zod.string().min(6),
});

export const LoginBody = zod.object({
  username: zod.string(),
  password: zod.string(),
});

export const SubmitGameResultBody = zod.object({
  puzzleDate: zod.string(),
  word: zod.string(),
  guesses: zod.array(zod.string()),
  won: zod.boolean(),
  guessCount: zod.number(),
});

export const HealthCheckResponse = zod.object({
  status: zod.string(),
});
