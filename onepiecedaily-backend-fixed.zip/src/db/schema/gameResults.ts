import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const gameResultsTable = pgTable("game_results", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  puzzleDate: text("puzzle_date").notNull(),
  word: text("word").notNull(),
  guesses: text("guesses").array().notNull(),
  won: boolean("won").notNull(),
  guessCount: integer("guess_count").notNull(),
  xpEarned: integer("xp_earned").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertGameResultSchema = createInsertSchema(gameResultsTable).omit({
  id: true,
  xpEarned: true,
  createdAt: true,
});
export type InsertGameResult = z.infer<typeof insertGameResultSchema>;
export type GameResult = typeof gameResultsTable.$inferSelect;
