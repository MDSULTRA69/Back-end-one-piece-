import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, usersTable, gameResultsTable } from "../db";
import { SubmitGameResultBody } from "../validation";
import { getLevelInfo, calcXpForResult } from "../lib/levels";

const router: IRouter = Router();

router.post("/game/result", async (req, res): Promise<void> => {
  const userId = req.session.userId;
  if (!userId) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }

  const parsed = SubmitGameResultBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { puzzleDate, word, guesses, won, guessCount } = parsed.data;

  const existing = await db
    .select({ id: gameResultsTable.id })
    .from(gameResultsTable)
    .where(
      and(
        eq(gameResultsTable.userId, userId),
        eq(gameResultsTable.puzzleDate, puzzleDate)
      )
    )
    .limit(1);

  if (existing.length > 0) {
    res.status(400).json({ error: "You already submitted a result for today" });
    return;
  }

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, userId))
    .limit(1);

  if (!user) {
    res.status(401).json({ error: "User not found" });
    return;
  }

  const xpEarned = calcXpForResult(won, guessCount);
  const newXp = user.xp + xpEarned;
  const previousLevel = user.level;
  const { level: newLevel, rank } = getLevelInfo(newXp);

  let newStreak = user.currentStreak;
  let newMaxStreak = user.maxStreak;

  if (won) {
    newStreak = user.currentStreak + 1;
    newMaxStreak = Math.max(newStreak, user.maxStreak);
  } else {
    newStreak = 0;
  }

  await db.insert(gameResultsTable).values({
    userId,
    puzzleDate,
    word,
    guesses,
    won,
    guessCount,
    xpEarned,
  });

  const [updated] = await db
    .update(usersTable)
    .set({
      xp: newXp,
      level: newLevel,
      totalGames: user.totalGames + 1,
      totalWins: won ? user.totalWins + 1 : user.totalWins,
      currentStreak: newStreak,
      maxStreak: newMaxStreak,
    })
    .where(eq(usersTable.id, userId))
    .returning();

  req.log.info({ userId, xpEarned, newLevel }, "Game result submitted");

  res.json({
    xpEarned,
    totalXp: updated.xp,
    level: newLevel,
    rank,
    leveledUp: newLevel > previousLevel,
    previousLevel,
    currentStreak: updated.currentStreak,
    maxStreak: updated.maxStreak,
  });
});

export default router;
