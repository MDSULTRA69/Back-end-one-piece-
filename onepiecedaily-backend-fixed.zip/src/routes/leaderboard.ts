import { Router, type IRouter } from "express";
import { desc } from "drizzle-orm";
import { db, usersTable } from "../db";
import { getLevelInfo } from "../lib/levels";

const router: IRouter = Router();

router.get("/leaderboard", async (req, res): Promise<void> => {
  const rawLimit = Array.isArray(req.query.limit) ? req.query.limit[0] : req.query.limit;
  const limit = Math.min(parseInt(String(rawLimit ?? "20"), 10) || 20, 100);

  const users = await db
    .select({
      id: usersTable.id,
      username: usersTable.username,
      xp: usersTable.xp,
      level: usersTable.level,
      totalWins: usersTable.totalWins,
      totalGames: usersTable.totalGames,
      currentStreak: usersTable.currentStreak,
    })
    .from(usersTable)
    .orderBy(desc(usersTable.xp))
    .limit(limit);

  const entries = users.map((u, i) => {
    const { rank } = getLevelInfo(u.xp);
    return {
      rank: i + 1,
      userId: u.id,
      username: u.username,
      xp: u.xp,
      level: u.level,
      rankTitle: rank,
      totalWins: u.totalWins,
      totalGames: u.totalGames,
      currentStreak: u.currentStreak,
    };
  });

  res.json({ entries });
});

export default router;
