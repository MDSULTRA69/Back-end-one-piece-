import { Router, type IRouter } from "express";
import bcrypt from "bcrypt";
import { eq, or } from "drizzle-orm";
import { db, usersTable } from "../db";
import { RegisterBody, LoginBody } from "../validation";
import { getLevelInfo } from "../lib/levels";

const router: IRouter = Router();

const SALT_ROUNDS = 12;

function formatUser(user: typeof usersTable.$inferSelect) {
  const { rank } = getLevelInfo(user.xp);
  return {
    id: user.id,
    username: user.username,
    email: user.email,
    xp: user.xp,
    level: user.level,
    rank,
    totalGames: user.totalGames,
    totalWins: user.totalWins,
    currentStreak: user.currentStreak,
    maxStreak: user.maxStreak,
  };
}

router.post("/auth/register", async (req, res): Promise<void> => {
  const parsed = RegisterBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { username, email, password } = parsed.data;

  const existing = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(
      or(eq(usersTable.username, username), eq(usersTable.email, email))
    )
    .limit(1);

  if (existing.length > 0) {
    res.status(409).json({ error: "Username or email already taken" });
    return;
  }

  const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

  const [user] = await db
    .insert(usersTable)
    .values({ username, email, passwordHash })
    .returning();

  req.session.userId = user.id;
  req.log.info({ userId: user.id }, "User registered");
  res.status(201).json(formatUser(user));
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { username, password } = parsed.data;

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.username, username))
    .limit(1);

  if (!user) {
    res.status(401).json({ error: "Invalid username or password" });
    return;
  }

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    res.status(401).json({ error: "Invalid username or password" });
    return;
  }

  req.session.userId = user.id;
  req.log.info({ userId: user.id }, "User logged in");
  res.json(formatUser(user));
});

router.post("/auth/logout", (req, res): void => {
  req.session.destroy(() => {
    res.json({ message: "Logged out" });
  });
});

router.get("/auth/me", async (req, res): Promise<void> => {
  const userId = req.session.userId;
  if (!userId) {
    res.status(401).json({ error: "Not authenticated" });
    return;
  }

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, userId))
    .limit(1);

  if (!user) {
    req.session.destroy(() => {});
    res.status(401).json({ error: "User not found" });
    return;
  }

  res.json(formatUser(user));
});

export { formatUser };
export default router;
